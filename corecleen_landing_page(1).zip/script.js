// Scroll to top button
const scrollBtn = document.getElementById("scrollTopBtn");
window.onscroll = function() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    scrollBtn.style.display = "block";
  } else {
    scrollBtn.style.display = "none";
  }
};
scrollBtn.onclick = function() {
  window.scrollTo({top: 0, behavior: 'smooth'});
};

// Modal functionality
const modal = document.getElementById("modal");
const ctaBtn = document.getElementById("cta-btn");
const closeBtn = document.querySelector(".close");

ctaBtn.onclick = function() {
  modal.style.display = "block";
};
closeBtn.onclick = function() {
  modal.style.display = "none";
};
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

// Animate feature cards on scroll
const featureCards = document.querySelectorAll('.feature-card');
function revealCards() {
  const windowHeight = window.innerHeight;
  featureCards.forEach(card => {
    const cardTop = card.getBoundingClientRect().top;
    if (cardTop < windowHeight - 50) {
      card.classList.add('visible');
    }
  });
}
window.addEventListener('scroll', revealCards);
window.addEventListener('load', revealCards);
