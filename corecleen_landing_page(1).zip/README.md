# Corecleen Landing Page

This is a responsive landing page built as part of the **Developer Entry Test 2025**.  
It presents **Corecleen Solutions Ltd**, a cleaning services company in Uganda.

---

## 📂 Project Structure

```
corecleen_landing_page/
├── index.html       # Main landing page
├── styles.css       # Stylesheet (responsive, hover effects, animations)
├── script.js        # JavaScript (modal, scroll-to-top, animations)
└── assets/          # Folder for images or icons (currently empty)
```

---

## 🚀 Features Implemented

- **Hero Section** with title, subtitle, and call-to-action button  
- **Features Section** with 3 feature cards (animated on scroll)  
- **Testimonials Section** with 2 sample client reviews  
- **Footer** with contact info and social media links  
- **Responsive Design** (mobile, tablet, desktop) using plain CSS  
- **Hover Effects** on buttons and links  
- **Scroll-to-Top Button** (appears after scrolling down)  
- **Modal Popup Form** when CTA button is clicked  
- **Bonus:** Feature cards animate (fade-in) on scroll with vanilla JS  

---

## 🛠️ Setup & Usage

1. **Download or Clone the Repo**
   ```bash
   git clone https://github.com/your-username/corecleen_landing_page.git
   cd corecleen_landing_page
   ```

2. **Open in Browser**
   Simply open `index.html` in your browser.

3. **Custom Assets**
   Place any images or logos inside the `/assets` folder and update the HTML accordingly.

---

## 📞 Contact Info (from Corecleen profile)
- **Email:** corecleensolutions@gmail.com  
- **Phone:** +256 (0) 707265146 / +256 (0) 786151990  

---

## 📜 License
This project was developed as part of an entry test and is for demonstration purposes only.
